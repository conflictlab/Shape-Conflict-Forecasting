library(testthat)
library(RcppThread)

test_check("RcppThread")
